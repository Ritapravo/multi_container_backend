#!/bin/bash

echo "# copying to server..."
docker exec server sh -c "mkdir -p /server_results"
docker exec server sh -c "g++ /app/SimpleEmailServerPhase1.cpp -o /s1.out"
docker exec -d server sh -c "/s1.out 5555 /app/passwd.txt > /server_results/log1.txt"
echo "..."
sleep 0.5
echo "# copying to client..."
docker cp /grader/testcase1.txt client:/
docker cp /grader/client_evaluate.sh client:/
docker exec client sh -c "bash /client_evaluate.sh 172.17.0.3:5555 /testcase1.txt"
echo "# Collecting results..."
sleep 0.5
echo "..."
sleep 0.5
su grader -c "mkdir -p results"
docker cp server:/server_results /grader/results/
docker cp client:/client_results /grader/results/
echo ""
echo "========== server log ==========="
echo ""
cat /grader/results/server_results/log1.txt
echo ""
echo "========== client log ==========="
echo ""
cat /grader/results/client_results/log1.txt
echo ""
