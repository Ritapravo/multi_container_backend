#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <fstream>
#include <string>
#include <iostream>
#include <string>
#include <vector>
#include <iostream> 
#include <sys/stat.h> 
#include <string>
#include <errno.h>
#include <dirent.h>
using namespace std;

#define BUFFER_LENGTH 1000

bool isNumber(string s) 
{ 
    for (int i = 0; i < s.length(); i++) 
        if (isdigit(s[i]) == false) 
            return false; 
  
    return true; 
} 

int remove_directory(string path)
{
   DIR *d = opendir(path.c_str());
   int ret_val = 0;
   if (d)
   {
      dirent *p;
      while ( (p = readdir(d) ) != NULL )
      {
        string path2(p->d_name);
          if (strcmp(p->d_name, ".") == 0 || strcmp(p->d_name, "..") == 0)
          {
             continue;
          }
          string nextpath = path + "/" + path2;
          if(p->d_type == DT_DIR){

            if(remove_directory(nextpath) != 0){
                ret_val = -1;
            }
          }
          else{
            if(remove(nextpath.c_str()) != 0){
                ret_val = -1;
            }
          }
      }

      closedir(d);
      if( remove(path.c_str()) != 0){
        ret_val = -1;
      }
   }

   return ret_val;
}

void usage(char *progname){
	fprintf(stderr, "%s <serverIPAddr:port> <user-name> <passwd> <user-folder> <list-of-ids> <interval>\n", progname);
}

int main(int argc, char *argv[]){
	if (argc != 7){
		usage(argv[0]);
		exit(1);
	}

	int sockfd;
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	int i = 0;
	while (argv[1][i] != ':'){
		if (argv[1][i] == '\0'){
			usage(argv[0]);
			exit(1);
		}
		i++;
	}

	string msgs = string(argv[5]);
	vector<string> msg_ids;
	string temp_msgs = msgs;
	while(true){
		size_t index = temp_msgs.find(",");
		if(index == string::npos){
			msg_ids.push_back(temp_msgs);
			break;
		}
		else{
			msg_ids.push_back(temp_msgs.substr(0,index));
			temp_msgs = temp_msgs.substr(index+1);
		}

	}

	for(int i = 0; i < msg_ids.size(); i++){
		if(! isNumber(msg_ids[i])){
			fprintf(stderr, "List does not parse into a number\n");
			exit(3);
		}
	}
	
	string arg1(argv[1]);
	string dest_ip = arg1.substr(0, i);
	string dest_port = arg1.substr(i + 1);
	struct sockaddr_in dest_addr;
	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(stoi(dest_port));
	dest_addr.sin_addr.s_addr = inet_addr(dest_ip.c_str());
	memset(&(dest_addr.sin_zero), '\0', 8);
	if (connect(sockfd, (struct sockaddr *)&dest_addr, sizeof(struct sockaddr)) == -1){
		fprintf(stderr, "Connection to server failed\n");
		exit(2);
	}
	else{
		cout << "ConnectDone: " << dest_ip << ":" << dest_port << endl;
	}

	char to_send[strlen("User: ") + strlen(argv[2]) + strlen(" Pass: ") +strlen(argv[3]) + 1];
	memset(to_send, '\0', sizeof(to_send));
	char op[] = "User: ";
	strcpy(to_send, op);
	strcat(to_send, argv[2]);
	char op1[] = " Pass: ";
	strcat(to_send, op1);
	strcat(to_send, argv[3]);
	char buffer[BUFFER_LENGTH];
	int sent;
	do {
		sent = send(sockfd, to_send, strlen(to_send), 0);
	} while (sent == -1);

	int size = 0;
	memset(buffer, '\0', BUFFER_LENGTH);
	int received = recv(sockfd, buffer, BUFFER_LENGTH, 0);
	size += received;
	std::cout << buffer;

	string folder_path = string(argv[4]);
	if(remove_directory(folder_path) != 0){
		fprintf(stderr, "Folder removal failed\n");
		exit(4);
	}
	if(mkdir(folder_path.c_str(), 0777) == -1){
		fprintf(stderr, "Folder creation failed\n");
		exit(4);
	}

	sleep(strtol(argv[6], NULL, 10));

	for(int i = 0; i < msg_ids.size(); i++){

		char retrv[strlen("RETRV ") + 1 + msg_ids[i].length()];
		memset(retrv, '\0', sizeof(retrv));
		char op2[] = "RETRV ";
		strcpy(retrv, op2);
		strcat(retrv, msg_ids[i].c_str());
		do {
			sent = send(sockfd, retrv, strlen(retrv), 0);
		} while (sent == -1);

		int buffersize = 0, recv_size = 0,size = 0, read_size, write_size,stat;

		char filedata[10241],verify = '1';
		FILE *fd;

		//Find the size of the fd
		char recv_data[BUFFER_LENGTH];
		memset(recv_data, '\0', BUFFER_LENGTH);
		
		do{
			stat = read(sockfd, &recv_data, sizeof(recv_data));
		}while(stat<0);

		string filename;
		string file_stats(recv_data);
		if (file_stats == "") {
			exit(5);
		}
		size_t index = file_stats.find(",");
		filename = file_stats.substr(0,index).substr(9);
		size = atoi(file_stats.substr(index+1).substr(9).c_str());
		string file_path = folder_path + "/" + filename;


		

		char buffer[] = "received";

		//Send our verification signal
		do{
			stat = write(sockfd, &buffer, sizeof(buffer));
		}while(stat<0);

		

		fd = fopen(file_path.c_str(), "w");

		if( fd == NULL) {
			printf("Error has occurred. fd file could not be opened\n");
			exit(8);
		 }

		while(recv_size < size) {
		
			
			do{
				read_size = read(sockfd,filedata, 10241);
			}while(read_size <0);

			write_size = fwrite(filedata,1,read_size, fd);
			// printf("Written fd size: %i\n",write_size); 

			if(read_size !=write_size) {
				printf("error in read write\n");
			}


			//Increment the total number of bytes read
			recv_size += read_size;
		}

		printf("Downloaded Message %s\n",msg_ids[i].c_str());
		
		fclose(fd);

	}

	char to_quit[strlen("quit") + 1];
	memset(to_quit, '\0', sizeof(to_quit));
	char op3[] = "quit";
	strcpy(to_quit, op3);
	do {
		sent = send(sockfd, to_quit, strlen(to_quit), 0);
	} while (sent == -1);





	

	close(sockfd);
}