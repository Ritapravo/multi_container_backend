#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <fstream>
#include <string>
#include <iostream>
#include <string>
using namespace std;

#define BUFFER_LENGTH 1000

void usage(char *progname){
	fprintf(stderr, "%s <serverIPAddr:port> <user-name> <passwd>\n", progname);
}

int main(int argc, char *argv[]){
	if (argc != 4){
		usage(argv[0]);
		exit(1);
	}

	int sockfd;
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	int i = 0;
	while (argv[1][i] != ':'){
		if (argv[1][i] == '\0'){
			usage(argv[0]);
			exit(1);
		}
		i++;
	}
	string arg1(argv[1]);
	string dest_ip = arg1.substr(0, i);
	string dest_port = arg1.substr(i + 1);
	struct sockaddr_in dest_addr;
	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(stoi(dest_port));
	dest_addr.sin_addr.s_addr = inet_addr(dest_ip.c_str());
	memset(&(dest_addr.sin_zero), '\0', 8);
	if (connect(sockfd, (struct sockaddr *)&dest_addr, sizeof(struct sockaddr)) == -1){
		fprintf(stderr, "Connection to server failed\n");
		exit(2);
	}
	else{
		cout << "ConnectDone: " << dest_ip << ":" << dest_port << endl;
	}

	char to_send[strlen("User: ") + strlen(argv[2]) + strlen(" Pass: ") +strlen(argv[3]) + 1];
	memset(to_send, '\0', sizeof(to_send));
	char op[] = "User: ";
	strcpy(to_send, op);
	strcat(to_send, argv[2]);
	char op1[] = " Pass: ";
	strcat(to_send, op1);
	strcat(to_send, argv[3]);
	char buffer[BUFFER_LENGTH];
	int sent;
	do {
		sent = send(sockfd, to_send, strlen(to_send), 0);
	} while (sent == -1);

	int size = 0;
	memset(buffer, '\0', BUFFER_LENGTH);
	int received = recv(sockfd, buffer, BUFFER_LENGTH, 0);
	size += received;
	std::cout << buffer;


	char list[strlen("LIST") + 1];
	memset(list, '\0', sizeof(list));
	char op2[] = "LIST";
	strcpy(list, op2);
	do {
		sent = send(sockfd, list, strlen(list), 0);
	} while (sent == -1);


	size = 0;
	memset(buffer, '\0', BUFFER_LENGTH);
	received = recv(sockfd, buffer, BUFFER_LENGTH, 0);
	size += received;
	std::cout << buffer;


	char to_quit[strlen("quit") + 1];
	memset(to_quit, '\0', sizeof(to_quit));
	char op3[] = "quit";
	strcpy(to_quit, op3);
	do {
		sent = send(sockfd, to_quit, strlen(to_quit), 0);
	} while (sent == -1);

	close(sockfd);
}