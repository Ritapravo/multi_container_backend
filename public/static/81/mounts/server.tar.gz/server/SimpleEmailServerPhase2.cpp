#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <fstream>
#include <string>
#include <iostream>
#include <map>
using namespace std;
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <dirent.h>

#define BACKLOG 10
#define BUFFER_LENGTH 1000

void usage(char *progname){
	fprintf(stderr, "%s <portNum> <passwdfile> <user-database>\n", progname);
}

int main(int argc, char *argv[]){
	if (argc != 4){
		usage(argv[0]);
		exit(1);
	}
	int sockfd;
	int port = atoi(argv[1]);
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	if (sockfd == -1){
		fprintf(stderr, "Socket creation failed");
		exit(2);
	}
	struct sockaddr_in my_addr;
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(port);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	memset(&(my_addr.sin_zero), '\0', 8);
	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1){
		fprintf(stderr, "Bind failed on port: %d\n", port);
		exit(2);
	}
	else{
		printf("BindDone: %d\n", port);
	}
	std::ifstream file(argv[2], ios::binary | ios::ate);
	if (!(file.good())){
		fprintf(stderr, "passwdfile not present or readable: %s\n", argv[2]);
		exit(3);
	}

	DIR* root = opendir(argv[3]);
	if(root == NULL) {
		fprintf(stderr, "user-database not present or readable: %s\n", argv[3]);
		exit(4);
	}

	closedir(root);

	if (listen(sockfd, BACKLOG) == -1){
		fprintf(stderr, "Listen failed\n");
		exit(3);
	}
	else{
		printf("ListenDone: %d\n", port);
	}

	while(true)
	{
		int new_sockfd;
		struct sockaddr_in client_addr;
		socklen_t sin_size = sizeof(struct sockaddr_in);

		new_sockfd = accept(sockfd, (struct sockaddr *)&client_addr, &sin_size);
		if (new_sockfd == -1){
			fprintf(stderr, "Accept failed\n");
			exit(3);
		}
		else{
			printf("Client: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
		}

		//TODO: what if greater than 100?
		char cred[1000];
		memset(cred, '\0', sizeof(cred));
		int received;
		do{
			received = recv(new_sockfd, cred, sizeof(cred), 0);
		} while(received == -1);
		string str(cred);

		if (strncmp(cred, "User: ", 6) != 0){
			printf("Unknown Command\n");
			close(new_sockfd);
			exit(4);
		}
		if (str.find("Pass: ") == std::string::npos) {
		    printf("Unknown Command\n");
			close(new_sockfd);
			exit(4);
		}

		int start_pass = str.find("Pass: ");
		string username = str.substr(6, start_pass-7);
		string pasword = str.substr(start_pass+6);
  
	    // Open an existing file 
	    std::ifstream file1(argv[2]);
	  
	    map<string,string> user_pass; 
	    string line = ""; 

	    while (getline(file1, line)) { 
	        std::vector<std::string> vec;
	        std::stringstream ss(line);

	        while( ss.good() ) {
	            string substr;
	            getline( ss, substr, ' ' );
	            vec.push_back( substr );
	        }

	        user_pass.insert({vec[0], vec[1]});
	        getline(file1, line);
	    }    

		if(user_pass.find(username) == user_pass.end()) {
			printf("Invalid User\n");
			close(new_sockfd);
			exit(5);
		}

		if(user_pass[username] != pasword) {
			printf("Wrong Passwd\n");
			close(new_sockfd);
			exit(6);
		}

		char to_send[strlen("Welcome ") + username.size() + 2];
		memset(to_send, '\0', sizeof(to_send));
		char op[] = "Welcome ";
		strcpy(to_send, op);
		strcat(to_send, username.c_str());
		strcat(to_send, "\n");
		printf("%s", to_send);
		int sent;
		sent = send(new_sockfd, to_send, strlen(to_send), 0);



		char cmd[1000];
		memset(cmd, '\0', sizeof(cmd));
		do{
			received = recv(new_sockfd, cmd, sizeof(cmd), 0);
		} while(received == -1);
		string str1(cmd);

		if(str1 == "LIST")
		{
			int found = false;
			int num = 0;
			//TODO : count num of files

			DIR* root = opendir(argv[3]);
			struct dirent *ent;
			while( (ent = readdir(root) )!= NULL)
			{
				if(!strcmp(ent->d_name, username.c_str()) && ent->d_type == DT_DIR){
					found = true;
					break;
				}
			}
			closedir(root);

			if(found)
			{
				string join("/");
				DIR* user_folder = opendir((argv[3]+join+username).c_str());
				if(user_folder == NULL) {
					fprintf(stderr, "%s: Folder Read Fail\n", username.c_str());
					closedir(user_folder);
					close(new_sockfd);
					exit(8);
				}
				while( (ent = readdir(user_folder) )!= NULL){
					num++;
				}
				num = num-2;
				closedir(user_folder);
			}
			else
			{
				fprintf(stdout, "%s: Folder Read Fail\n", username.c_str());
				close(new_sockfd);
				exit(8);
			}
			
			std::string num_msg = to_string(num);
			char to_list[username.size() + strlen("Welcome : No of messages ") + num_msg.size() + strlen(" \n") + 1];
			memset(to_list, '\0', sizeof(to_list));
			char op1[] = ": No of messages ";
			strcpy(to_list, username.c_str());
			strcat(to_list, op1);
			strcat(to_list, num_msg.c_str());
			strcat(to_list, " \n");
			printf("%s", to_list);
			sent = send(new_sockfd, to_list, strlen(to_list), 0);
		}
		else
		{
			printf("Unknown Command\n");
			close(new_sockfd);
			exit(7);
		}

		char cmd1[1000];
		memset(cmd1, '\0', sizeof(cmd1));
		do{
			received = recv(new_sockfd, cmd1, sizeof(cmd1), 0);
		} while(received == -1);
		string str2(cmd1);

		if (str2 == "quit")
		{
			std::cout << "Bye " << username << std::endl;
			close(new_sockfd);
		}
		else
		{
			printf("Unknown Command\n");
			close(new_sockfd);
			exit(7);
		}
	}

	// closedir(root);
}