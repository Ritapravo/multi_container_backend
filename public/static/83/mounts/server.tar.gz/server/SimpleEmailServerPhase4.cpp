#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <fstream>
#include <string>
#include <iostream>
#include <map>
using namespace std;
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <dirent.h>

#define BACKLOG 10
#define BUFFER_LENGTH 1000

void usage(char *progname){
	fprintf(stderr, "%s <portNum> <passwdfile> <user-database>\n", progname);
}

int main(int argc, char *argv[]){
	if (argc != 4){
		usage(argv[0]);
		exit(1);
	}
	int sockfd;
	int port = atoi(argv[1]);
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	if (sockfd == -1){
		fprintf(stderr, "Socket creation failed");
		exit(2);
	}
	struct sockaddr_in my_addr;
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(port);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	memset(&(my_addr.sin_zero), '\0', 8);
	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1){
		fprintf(stderr, "Bind failed on port: %d\n", port);
		exit(2);
	}
	else{
		printf("BindDone: %d\n", port);
	}
	std::ifstream file(argv[2], ios::binary | ios::ate);
	if (!(file.good())){
		fprintf(stderr, "passwdfile not present or readable: %s\n", argv[2]);
		exit(3);
	}

	DIR* root = opendir(argv[3]);
	if(root == NULL) {
		fprintf(stderr, "user-database not present or readable: %s\n", argv[3]);
		exit(4);
	}

	closedir(root);

	if (listen(sockfd, BACKLOG) == -1){
		fprintf(stderr, "Listen failed\n");
		exit(3);
	}
	else{
		printf("ListenDone: %d\n", port);
	}

	fd_set rdset, tmpset, tmpset2, writeset;
	int maxfd;
	int new_sockfd, result;
	struct sockaddr_in client_addr;
	socklen_t sin_size = sizeof(struct sockaddr_in);
	char buffer[BUFFER_LENGTH];

	FD_ZERO(&rdset);
	FD_ZERO(&writeset);
	FD_SET(sockfd, &rdset);
	maxfd = sockfd;
	map<int, string> file_map;
	map<int, int> bytes_sent;
	map<int, string> user_map;
	map<int, int> proc_stage;
	map<int, int> num_msgs;
	map<int, int> orig_file_size;

	while(true){
		// cout<<"Hey"<<endl;
		memcpy(&tmpset, &rdset, sizeof(tmpset));
		memcpy(&tmpset2, &writeset, sizeof(writeset));
		result = select(maxfd + 1, &tmpset, &tmpset2, NULL, NULL);
		if (result == 0){
			continue;
		}
		else if (result == -1){
		}
		else{
			if (FD_ISSET(sockfd, &tmpset)){
				new_sockfd = accept(sockfd, (struct sockaddr *)&client_addr, &sin_size);
				if (new_sockfd == -1){
					fprintf(stderr, "Accept failed\n");
				}
				else{
					printf("Client: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
					FD_SET(new_sockfd, &rdset);
					proc_stage[new_sockfd] = 0;
					maxfd = (maxfd < new_sockfd) ? new_sockfd : maxfd;
				}
				FD_CLR(sockfd, &tmpset);
			}
			// cout<<"Hey2"<<endl;

			for (int i = 0; i < maxfd + 1; i++){
				if (FD_ISSET(i, &tmpset2)){
					if(proc_stage[i] == 0){
						if(user_map.find(i) == user_map.end()){
							printf("User DB updation gone wrong\n");
							FD_CLR(i, &writeset);
							close(i);
							exit(9);
						}
						else{
							string username = user_map[i];
							char to_send[strlen("Welcome ") + username.size() + 2];
							memset(to_send, '\0', sizeof(to_send));
							char op[] = "Welcome ";
							strcpy(to_send, op);
							strcat(to_send, username.c_str());
							strcat(to_send, "\n");
							printf("%s", to_send);
							int sent;
							sent = send(i, to_send, strlen(to_send), 0);
							FD_CLR(i, &writeset);
							FD_SET(i, &rdset);
							proc_stage[i] = 2;
						}
					}
					else if(proc_stage[i] == 1){
						string num_msg = to_string(num_msgs[i]);
						string username = user_map[i];
						char to_list[username.size() + strlen("Welcome : No of messages ") + num_msg.size() + strlen(" \n") + 1];
						memset(to_list, '\0', sizeof(to_list));
						char op1[] = ": No of messages ";
						strcpy(to_list, username.c_str());
						strcat(to_list, op1);
						strcat(to_list, num_msg.c_str());
						strcat(to_list, " \n");
						printf("%s", to_list);
						int sent;
						sent = send(i, to_list, strlen(to_list), 0);
						FD_CLR(i, &writeset);
						FD_SET(i, &rdset);
						proc_stage[i] = 2;

					}
					else if(proc_stage[i] == 2){
						string filesize = to_string(orig_file_size[i]);
						string exact_filename = file_map[i];
						char to_send[strlen("filename:") + exact_filename.size() + strlen("filesize:") + filesize.size() + 2];
						memset(to_send, '\0', sizeof(to_send));
						strcpy(to_send, "filename:");
						strcat(to_send, exact_filename.c_str());
						strcat(to_send, ",");
						strcat(to_send, "filesize:");
						strcat(to_send, filesize.c_str());
						// printf("%s\n", to_send );
						int sent;
						sent = send(i, to_send, strlen(to_send), 0);
						FD_CLR(i, &writeset);
						FD_SET(i, &rdset);
						proc_stage[i] = 3;
					}
					else if(proc_stage[i] == 3){
						string join = "/";
						string username = user_map[i];
						string exact_filepath = argv[3]+join+username+join+file_map[i];
						ifstream f(exact_filepath, ios::binary | ios::ate);
						int file_size = f.tellg();
						memset(buffer, '\0', BUFFER_LENGTH);
						f.seekg(bytes_sent[i], ios::beg);
						f.read(buffer, min(BUFFER_LENGTH, file_size - bytes_sent[i]));
						int sent = send(i, buffer, min(BUFFER_LENGTH, file_size - bytes_sent[i]), 0);
						FD_CLR(i, &writeset);
						if (sent != -1){
							bytes_sent[i] += sent;
							if (bytes_sent[i] >= file_size){
								// printf("TransferDone: %d bytes\n", bytes_sent[i]);
								proc_stage[i] = 2;
								FD_SET(i, &rdset);
							}
							else{
								FD_SET(i, &writeset);
							}
						}
						f.close();
						// cout<<proc_stage[i]<<endl;

					}
					else if(proc_stage[i] == 4){
						string username = user_map[i];
						cout << "Bye " << username << endl;
						FD_CLR(i, &writeset);
						close(i);
						proc_stage.erase(i);
						file_map.erase(i);
						user_map.erase(i);
						orig_file_size.erase(i);
						num_msgs.erase(i);
						bytes_sent.erase(i);
					}
					
				}
			}

			for (int i = 0; i < maxfd + 1; i++){
				if (FD_ISSET(i, &tmpset)){
					// cout<<"Read "<<i<<endl;
					char read_buffer[BUFFER_LENGTH];
					memset(read_buffer, '\0', sizeof(read_buffer));
					int received;
					do {
						received = recv(i, read_buffer, sizeof(read_buffer), 0);
					} while(received == -1);
					FD_CLR(i, &rdset);
					string read_str(read_buffer);
					if(read_str == "quit"){
						if(user_map.find(i) == user_map.end()){
							printf("Quit without login\n");
							close(i);
							exit(9);
						}
						proc_stage[i] = 4;
						FD_SET(i, &writeset);
					}
					else if(read_str == "LIST"){
						if(proc_stage[i] != 1){
							printf("Unknown Command\n");
							close(i);
							exit(4);
						}
						else{
							int found = false;
							int num = 0;
							string username = user_map[i];
							//TODO : count num of files
							DIR* root = opendir(argv[3]);
							struct dirent *ent;
							while( (ent = readdir(root) )!= NULL)
							{
								if(!strcmp(ent->d_name, username.c_str()) && ent->d_type == DT_DIR){
									found = true;
									break;
								}
							}
							closedir(root);

							if(found)
							{
								string join("/");
								DIR* user_folder = opendir((argv[3]+join+username).c_str());
								if(user_folder == NULL) {
									fprintf(stderr, "%s: Folder Read Fail\n", username.c_str());
									close(i);
									exit(8);
								}
								while( (ent = readdir(user_folder) )!= NULL){
									num++;
								}
								num = num-2;
								closedir(user_folder);
								num_msgs[i] = num;
								FD_SET(i, &writeset);
							}
							else
							{
								fprintf(stderr, "%s: Folder Read Fail\n", username.c_str());
								close(i);
								exit(8);
							}
						}
					}
					else if(read_str == "received"){
						if(proc_stage[i] != 3){
							printf("Unknown Command\n");
							close(i);
							exit(4);
						}
						else{
							FD_SET(i, &writeset);
						}

					}
					else if(read_str.substr(0,6) == "RETRV "){
						if(proc_stage[i] != 2){
							printf("Unknown Command\n");
							close(i);
							exit(4);
						}
						else{
							if(read_str.length() > 6){

								string filename = read_str.substr(6);
								string username = user_map[i];
								string exact_filename;
								
								string join("/");

								DIR* user_folder = opendir((argv[3]+join+username).c_str());

								if(user_folder == NULL) {
									fprintf(stderr, "Message Read Fail\n");
									close(i);
									exit(8);
								}
								
								
								bool file_found = false;
								struct dirent* ent2;
								while( (ent2 = readdir(user_folder) )!= NULL){

									if(ent2->d_type != DT_DIR){
							    		string cur_filename(ent2->d_name);
							    		size_t lastindex = cur_filename.find_last_of("."); 
										string raw_filename = cur_filename.substr(0, lastindex);
										if(raw_filename == filename){
											file_found = true;
											exact_filename = cur_filename;
											break;
										}

							    		
							    	}
								}

								closedir(user_folder);


								if(! file_found){
									fprintf(stderr, "%s: File Not Found\n", filename.c_str());
									close(i);
									exit(8);
								}

								FILE *fd;
								int size, read_size, stat;
								string exact_filepath = argv[3]+join+username+join+exact_filename;

								fd = fopen(exact_filepath.c_str(), "r");


								if(fd == NULL) {
									// cout<<exact_filename<<endl;
									fprintf(stderr, "Message Read Fail");
									close(i);
									exit(8);
								}


								fseek(fd, 0, SEEK_END);
								size = ftell(fd);
								fseek(fd, 0, SEEK_SET);

								fclose(fd);

								bytes_sent[i] = 0;
								file_map[i] = exact_filename;
								orig_file_size[i] = size;
								FD_SET(i, &writeset);
								printf("Transferring Message %s\n",filename.c_str());

							}

						}

					}	
					else{
						if(proc_stage[i] != 0){
							printf("Unknown Command\n");
							close(i);
							exit(4);
						}
						else{
							if (strncmp(read_buffer, "User: ", 6) != 0){
								printf("Unknown Command\n");
								close(i);
								exit(4);
							}
							if (read_str.find("Pass: ") == std::string::npos) {
							    printf("Unknown Command\n");
								close(i);
								exit(4);
							}

							int start_pass = read_str.find("Pass: ");
							string username = read_str.substr(6, start_pass-7);
							string pasword = read_str.substr(start_pass+6);
					  
						    // Open an existing file 
						    std::ifstream file1(argv[2]);
						  
						    map<string,string> user_pass; 
						    string line = ""; 

						    while (getline(file1, line)) { 
						        std::vector<std::string> vec;
						        std::stringstream ss(line);

						        while( ss.good() ) {
						            string substr;
						            getline( ss, substr, ' ' );
						            vec.push_back( substr );
						        }

						        user_pass.insert({vec[0], vec[1]});
						        getline(file1, line);
						    }  

							if(user_pass.find(username) == user_pass.end()) {
								printf("Invalid User\n");
								close(i);
								exit(5);
							}

							if(user_pass[username] != pasword) {
								printf("Wrong Passwd\n");
								close(i);
								exit(6);
							}

							user_map[i] = username;
							FD_SET(i, &writeset);

						}
					}	
				}
			}
		}
	}
}
