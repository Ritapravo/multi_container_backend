#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <fstream>
#include <string>
#include <iostream>
#include <map>
using namespace std;
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <dirent.h>

#define BACKLOG 10
#define BUFFER_LENGTH 1000

void usage(char *progname){
	fprintf(stderr, "%s <portNum> <passwdfile> <user-database>\n", progname);
}

int main(int argc, char *argv[]){
	if (argc != 4){
		usage(argv[0]);
		exit(1);
	}
	int sockfd;
	int port = atoi(argv[1]);
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	if (sockfd == -1){
		fprintf(stderr, "Socket creation failed");
		exit(2);
	}
	struct sockaddr_in my_addr;
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(port);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	memset(&(my_addr.sin_zero), '\0', 8);
	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1){
		fprintf(stderr, "Bind failed on port: %d\n", port);
		exit(2);
	}
	else{
		printf("BindDone: %d\n", port);
	}
	std::ifstream file(argv[2], ios::binary | ios::ate);
	if (!(file.good())){
		fprintf(stderr, "passwdfile not present or readable: %s\n", argv[2]);
		exit(3);
	}

	DIR* root = opendir(argv[3]);
	if(root == NULL) {
		fprintf(stderr, "user-database not present or readable: %s\n", argv[3]);
		exit(4);
	}
	closedir(root);

	if (listen(sockfd, BACKLOG) == -1){
		fprintf(stderr, "Listen failed\n");
		exit(3);
	}
	else{
		printf("ListenDone: %d\n", port);
	}

	while(true)
	{
		DIR* temproot = opendir(argv[3]);
		int new_sockfd;
		struct sockaddr_in client_addr;
		socklen_t sin_size = sizeof(struct sockaddr_in);

		new_sockfd = accept(sockfd, (struct sockaddr *)&client_addr, &sin_size);
		if (new_sockfd == -1){
			fprintf(stderr, "Accept failed\n");
			exit(3);
		}
		else{
			printf("Client: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
		}

		//TODO: what if greater than 100?
		char cred[1000];
		memset(cred, '\0', sizeof(cred));
		int received;
		do{
			received = recv(new_sockfd, cred, sizeof(cred), 0);
		} while(received == -1);
		string str(cred);

		if (strncmp(cred, "User: ", 6) != 0){
			printf("Unknown Command\n");
			close(new_sockfd);
			exit(4);
		}
		if (str.find("Pass: ") == std::string::npos) {
		    printf("Unknown Command\n");
			close(new_sockfd);
			exit(4);
		}

		int start_pass = str.find("Pass: ");
		string username = str.substr(6, start_pass-7);
		string pasword = str.substr(start_pass+6);
  
	    // Open an existing file 
	    std::ifstream file1(argv[2]);
	  
	    map<string,string> user_pass; 
	    string line = ""; 

	    while (getline(file1, line)) { 
	        std::vector<std::string> vec;
	        std::stringstream ss(line);

	        while( ss.good() ) {
	            string substr;
	            getline( ss, substr, ' ' );
	            vec.push_back( substr );
	        }

	        user_pass.insert({vec[0], vec[1]});
	        getline(file1, line);
	    }    

		if(user_pass.find(username) == user_pass.end()) {
			printf("Invalid User\n");
			close(new_sockfd);
			exit(5);
		}

		if(user_pass[username] != pasword) {
			printf("Wrong Passwd\n");
			close(new_sockfd);
			exit(6);
		}

		char to_send[strlen("Welcome ") + username.size() + 2];
		memset(to_send, '\0', sizeof(to_send));
		char op[] = "Welcome ";
		strcpy(to_send, op);
		strcat(to_send, username.c_str());
		strcat(to_send, "\n");
		printf("%s", to_send);
		int sent;
		sent = send(new_sockfd, to_send, strlen(to_send), 0);

		struct dirent *ent;
		bool found = false;

		while( (ent = readdir(temproot) )!= NULL)
		{
			if(!strcmp(ent->d_name, username.c_str()) && ent->d_type == DT_DIR){
				found = true;
				break;
			}
		}
		closedir(temproot);

		if(! found)
		{
			fprintf(stderr, "%s: Folder Read Failure\n", username.c_str());
			close(new_sockfd);
			exit(8);
		}
		




		while(true){

			char cmd[1000];
			memset(cmd, '\0', sizeof(cmd));
			do{
				received = recv(new_sockfd, cmd, sizeof(cmd), 0);
			} while(received == -1);
			string str1(cmd);

			if (str1 == "quit")
			{
				std::cout << "Bye " << username << std::endl;
				close(new_sockfd);
				break;
			}

			else if(str1 == "LIST")
			{
				int found = false;
				int num = 0;
				//TODO : count num of files
				struct dirent *ent;
				DIR* temproot = opendir(argv[3]);
				while( (ent = readdir(temproot) )!= NULL)
				{
					if(!strcmp(ent->d_name, username.c_str()) && ent->d_type == DT_DIR){
						found = true;
						break;
					}
				}

				closedir(temproot);

				if(found)
				{
					string join("/");
					DIR* user_folder = opendir((argv[3]+join+username).c_str());
					if(user_folder == NULL) {
						fprintf(stderr, "%s: Folder Read Fail\n", username.c_str());
						close(new_sockfd);
						exit(8);
					}
					
					while( (ent = readdir(user_folder) )!= NULL){
						num++;
					}
					closedir(user_folder);
					num = num-2;
				}
				else
				{
					fprintf(stderr, "%s: Folder Read Fail\n", username.c_str());
					close(new_sockfd);
					exit(8);
				}
				
				std::string num_msg = to_string(num);
				char to_list[username.size() + strlen("Welcome : No of messages ") + num_msg.size() + strlen(" \n") + 1];
				memset(to_list, '\0', sizeof(to_list));
				char op1[] = ": No of messages ";
				strcpy(to_list, username.c_str());
				strcat(to_list, op1);
				strcat(to_list, num_msg.c_str());
				strcat(to_list, " \n");
				printf("%s", to_list);
				sent = send(new_sockfd, to_list, strlen(to_list), 0);
			}

			else if(str1.substr(0,6) == "RETRV ")
			{
				if(str1.length() > 6){

					string filename = str1.substr(6);
					string exact_filename;
					
					string join("/");

					DIR* user_folder = opendir((argv[3]+join+username).c_str());

					if(user_folder == NULL) {
						fprintf(stderr, "Message Read Fail\n");
						close(new_sockfd);
						exit(8);
					}
					
					
					bool file_found = false;
					struct dirent* ent2;
					while( (ent2 = readdir(user_folder) )!= NULL){

						if(ent2->d_type != DT_DIR){
				    		string cur_filename(ent2->d_name);
				    		size_t lastindex = cur_filename.find_last_of("."); 
							string raw_filename = cur_filename.substr(0, lastindex);
							if(raw_filename == filename){
								file_found = true;
								exact_filename = cur_filename;
								break;
							}

				    		
				    	}
					}

					closedir(user_folder);


					if(! file_found){
						fprintf(stdout, "Message Read Fail\n");
						close(new_sockfd);
						break;
						// exit(8);
					} else{
						FILE *fd;
						int size, read_size, stat;
						char send_buffer[10240], read_buffer[256];
						string exact_filepath = argv[3]+join+username+join+exact_filename;

						fd = fopen(exact_filepath.c_str(), "r");


						if(fd == NULL) {
							// cout<<exact_filename<<endl;
							fprintf(stderr, "Message Read Fail");
							close(new_sockfd);
							exit(8);
						}

						printf("Transferring Message %s\n",filename.c_str());

						fseek(fd, 0, SEEK_END);
						size = ftell(fd);
						fseek(fd, 0, SEEK_SET);
						std::string filesize = to_string(size);
						char to_send[strlen("filename:") + exact_filename.size() + strlen("filesize:") + filesize.size() + 2];
						memset(to_send, '\0', sizeof(to_send));
						strcpy(to_send, "filename:");
						strcat(to_send, exact_filename.c_str());
						strcat(to_send, ",");
						strcat(to_send, "filesize:");
						strcat(to_send, filesize.c_str());
						// printf("%s\n", to_send );
						int sent;
						sent = send(new_sockfd, to_send, strlen(to_send), 0);


						do { //Read while we get errors that are due to signals.
							stat=read(new_sockfd, &read_buffer , 255);
						} while (stat < 0);

						string status(read_buffer);

						if(status != "received"){
							fprintf(stderr, "Error at Client\n");
							close(new_sockfd);
							exit(8);
						}

						// printf("Received data in socket\n");
						// printf("Socket data: %s\n", read_buffer);

						while(!feof(fd)) {
						//while(packet_index = 1){
							//Read from the file into our send buffer
							read_size = fread(send_buffer, 1, sizeof(send_buffer)-1, fd);

							//Send data through our socket 
							do{
								stat = write(new_sockfd, send_buffer, read_size);  
							}while (stat < 0);
							bzero(send_buffer, sizeof(send_buffer));
						}

						fclose(fd);
					}
				}
				else{
					printf("Unknown Command\n");
					close(new_sockfd);
					exit(7);
				}
			}
			else
			{
				printf("Unknown Command\n");
				close(new_sockfd);
				exit(7);
			}

		}

		
	}

	
}