#!/bin/bash

echo "starting server..."

docker exec -it server sh -c 'mkdir -p /server_results'
docker exec -itd server sh -c 'g++ /app/SimpleEmailServerPhase1.cpp -o /s1.out && /s1.out 5555 /app/passwd.txt > /server_results/log1.txt'

server_ip=$(nslookup server | awk '/^Address: / { print $2 }')
echo "server IP ${server_ip}:5555"

echo "..."
sleep 0.5
echo "..."
sleep 0.5

docker cp /grader/client_evaluate.sh client:/
docker cp /grader/testcase1.txt client:/
docker exec -it client sh -c "bash /client_evaluate.sh ${server_ip}:5555 /testcase1.txt"

echo "fetching results..."
sleep 0.5
echo "..."
sleep 0.5
mkdir -p results
docker cp server:/server_results /grader/results/
docker cp client:/client_results /grader/results/
echo "results fetch completed"
echo ""
echo "========== server log ==========="
echo ""
cat /grader/results/server_results/log1.txt
echo ""
echo "========== client log ==========="
echo ""
cat /grader/results/client_results/log1.txt
echo ""

