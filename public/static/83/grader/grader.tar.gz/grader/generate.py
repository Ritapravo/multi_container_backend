import yaml
import shlex


def parseVariable(input_string):
    return input_string.format(**user_variables)

def parseYml (path):
    with open(path, "r") as f:
        data = yaml.safe_load(f)
    return data


def handlePrint(arr):
    if(arr[1]=='-f'):
        print('cat {}'.format(parseVariable(arr[2])))
    else:
        print('echo "{}"'.format(parseVariable(arr[1])))


def handleRun(arr):
    if(arr[1]==data['NAME']):
        print ('su grader -c "{}"'.format(parseVariable(arr[2])))
    elif ('-d' in arr):
        print('docker exec -itd {} sh -c "{}"'.format( parseVariable(arr[2]), parseVariable(arr[3]) ))
    else: 
        print('docker exec -it {} sh -c "{}"'.format( parseVariable(arr[1]), parseVariable(arr[2]) ))


def handleCopy(arr):
    if(':' in arr[1] or ':' in arr[2]):
        print('docker cp {} {}'.format( parseVariable(arr[1]), parseVariable(arr[2]) ))
    else :
        print('cp {} {}'.format( parseVariable(arr[1]), parseVariable(arr[2]) )) 

def handleStore(arr):
    user_variables[arr[1]] = arr[2]

def handleSleep(arr):
    print('sleep {}'.format( parseVariable(arr[1]) ))

## Global variables
user_variables = dict()

if __name__=="__main__":

    data = parseYml("/grader/config.yml")

    print('#!/bin/bash')
    print('')

    for variable in data['VARS']:
        user_variables[variable]=data['VARS'][variable]
    
    for line in data['EXECUTE']:
        temp = shlex.split(line)
        cmd = temp[0]
        # print(temp)
        commands = []
        match cmd:
            case "PRINT":
                handlePrint(temp)
            case "RUN":
                handleRun(temp)
            case "COPY":
                handleCopy(temp)
            case "STORE":
                handleStore(temp)
            case "SLEEP":
                handleSleep(temp)
                
        
            
        