#!/bin/bash

# echo "inside client $1 $2"
mkdir -p /client_results
# echo $1
# echo $2
rm -f /client_results/log1.txt
touch /client_results/log1.txt
while IFS= read -r line; do
  username=$(echo "$line" | awk '{print $1}')
  password=$(echo "$line" | awk '{print $2}')

  # echo "/c1.out $1 $username $password> /client_results/log1.txt"
  g++ /app/SimpleEmailClientPhase1.cpp  -o /c1.out 
  /c1.out "$1" "$username" "$password" > /client_results/log1.txt

done < $2

