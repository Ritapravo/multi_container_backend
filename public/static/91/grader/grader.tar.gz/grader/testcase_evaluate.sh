#!/bin/bash

obtained_server_log="/grader/obtained_results/testcase1/server.txt"
obtained_client_log="/grader/obtained_results/testcase1/client.txt"

expected_server_log="/grader/expected_results/testcase1/server.txt"
expected_client_log="/grader/expected_results/testcase1/client.txt"



file2="file2.txt"

if [ -f "$obtained_server_log" ] && [ -f "$obtained_client_log" ] && [ -f "$expected_server_log" ] && [ -f "$expected_client_log" ]; then
    
    sed -i '/Client:/d' $obtained_server_log
    sed -i '/Client:/d' $expected_server_log 
    sed -i '/ConnectDone:/d' $obtained_client_log
    sed -i '/ConnectDone:/d' $expected_client_log

    if diff -q $obtained_server_log $expected_server_log > /dev/null && diff -q $obtained_client_log $expected_client_log > /dev/null; then
        echo "Test Case Passed"
        echo "Verdict : Pass"
    else
        echo "Test Case Failed"
        echo "Verdict : Fail"
    fi
else
    echo "Failed to get some logs"
fi
