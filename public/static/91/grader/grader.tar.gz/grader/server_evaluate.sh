#!/bin/bash

echo "inside server"
mkdir -p /server_results
g++ /app/SimpleEmailServerPhase1.cpp -o /s1.out && /s1.out 5555 /app/passwd.txt > /server_results/log1.txt &
# kill -9 $(ps | grep 'server_evaluate' | awk '{print $1}')
# kill -9 $(ps | grep 's1.out' | awk '{print $1}')
